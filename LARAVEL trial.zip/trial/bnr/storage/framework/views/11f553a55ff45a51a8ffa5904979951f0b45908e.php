<h1> Welcome to BNR </h1>
<p> This is the welcome page </p><?php /**PATH C:\laravel\trial\bnr\resources\views/welcome.blade.php ENDPATH**/ ?>