<h1>homepage</h1>   
<p>This is the home page</p><?php /**PATH C:\laravel\trial\bnr\resources\views/Home.blade.php ENDPATH**/ ?>