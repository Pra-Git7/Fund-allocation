<h1> Welcome to BNR </h1>
<p> This is the welcome page </p>